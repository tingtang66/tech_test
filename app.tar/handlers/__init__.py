from jinja2 import Environment, PackageLoader

Env = Environment(loader=PackageLoader('template', ''))